
package com.mycompany.patientcategory;

/**
 *
 * @author naledi
 */

public enum PatientCategory {
INPATIENT,
OUTPATIENT,
EMERGENCY
}
