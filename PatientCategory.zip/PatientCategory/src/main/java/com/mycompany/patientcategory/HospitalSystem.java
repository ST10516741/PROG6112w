
package com.mycompany.patientcategory;

/**
 *
 * @author naledi
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HospitalSystem {

    private static final int TOTAL_BEDS = 20;
    private static final String WARD_NUMBER = "W01";

    private final List<Patient> patients;
    private final Patient[] beds;

    public HospitalSystem() {
        patients = new ArrayList<>();
        beds = new Patient[TOTAL_BEDS];
    }

    // ----------------------------------------------------
    // PATIENT MANAGEMENT
    // ----------------------------------------------------

    public boolean registerPatient(Patient patient) {

        if (patient == null) {
            return false;
        }

        if (searchPatient(patient.getPatientId()) != null) {
            return false;
        }

        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {

        if (patientId == null) {
            return null;
        }

        for (Patient patient : patients) {
            if (patient.getPatientId().equalsIgnoreCase(patientId)) {
                return patient;
            }
        }

        return null;
    }

    public boolean updatePatient(String patientId,
                                 String firstName,
                                 String lastName,
                                 int age,
                                 String gender,
                                 String medicalCondition,
                                 PatientCategory category) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // If an inpatient is changed to another category,
        // release their existing bed.
        if (patient.getCategory() == PatientCategory.INPATIENT
                && category != PatientCategory.INPATIENT) {

            releaseBed(patientId);
        }

        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setMedicalCondition(medicalCondition);
        patient.setCategory(category);

        return true;
    }

    public boolean deletePatient(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // Release bed first if patient is an inpatient.
        if (patient instanceof Inpatient) {
            releaseBed(patientId);
        }

        patients.remove(patient);
        return true;
    }

    public List<Patient> getPatients() {
        return new ArrayList<>(patients);
    }

    public void displayAllPatients() {

        if (patients.isEmpty()) {
            System.out.println(" No patients registered.");
            return;
        }

        System.out.println(" ========== ALL PATIENTS ==========");

        for (Patient patient : patients) {
            patient.displayDetails();
        }
    }

    // ----------------------------------------------------
    // SORTING
    // ----------------------------------------------------

    public List<Patient> sortBySurname() {

        List<Patient> sortedPatients = new ArrayList<>(patients);

        sortedPatients.sort(
                Comparator.comparing(
                        Patient::getLastName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        return sortedPatients;
    }

    public List<Patient> sortByPatientId() {

        List<Patient> sortedPatients = new ArrayList<>(patients);

        sortedPatients.sort(
                Comparator.comparing(
                        Patient::getPatientId,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        return sortedPatients;
    }

    public void displaySortedBySurname() {

        List<Patient> sorted = sortBySurname();

        System.out.println(" ========== PATIENTS SORTED BY SURNAME ==========");

        for (Patient patient : sorted) {
            patient.displayDetails();
        }
    }

    public void displaySortedByPatientId() {

        List<Patient> sorted = sortByPatientId();

        System.out.println(" ========== PATIENTS SORTED BY PATIENT ID ==========");

        for (Patient patient : sorted) {
            patient.displayDetails();
        }
    }

    // ----------------------------------------------------
    // BED MANAGEMENT
    // ----------------------------------------------------

    private int getBedIndex(String bedNumber) {

        if (bedNumber == null) {
            return -1;
        }

        String bed = bedNumber.toUpperCase();

        if (!bed.matches("B(0[1-9]|1[0-9]|20)")) {
            return -1;
        }

        return Integer.parseInt(bed.substring(1)) - 1;
    }

    public boolean allocateBed(String patientId, String bedNumber) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // Only inpatients can receive beds.
        if (!(patient instanceof Inpatient)
                || patient.getCategory() != PatientCategory.INPATIENT) {
            return false;
        }

        Inpatient inpatient = (Inpatient) patient;

        // Check whether patient already has a bed.
        if (inpatient.getBedNumber() != null
                && !inpatient.getBedNumber().equalsIgnoreCase("NONE")) {
            return false;
        }

        int index = getBedIndex(bedNumber);

        if (index == -1) {
            return false;
        }

        // Prevent allocating an occupied bed.
        if (beds[index] != null) {
            return false;
        }

        beds[index] = inpatient;

        inpatient.setWardNumber(WARD_NUMBER);
        inpatient.setBedNumber(String.format("B%02d", index + 1));

        return true;
    }

    public boolean allocateFirstAvailableBed(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        if (!(patient instanceof Inpatient)) {
            return false;
        }

        for (int i = 0; i < TOTAL_BEDS; i++) {

            if (beds[i] == null) {

                Inpatient inpatient = (Inpatient) patient;

                beds[i] = inpatient;

                inpatient.setWardNumber(WARD_NUMBER);
                inpatient.setBedNumber(
                        String.format("B%02d", i + 1)
                );

                return true;
            }
        }

        // No beds available.
        return false;
    }

    public boolean releaseBed(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null || !(patient instanceof Inpatient)) {
            return false;
        }

        Inpatient inpatient = (Inpatient) patient;

        String bedNumber = inpatient.getBedNumber();

        if (bedNumber == null || bedNumber.equalsIgnoreCase("NONE")) {
            return false;
        }

        int index = getBedIndex(bedNumber);

        if (index == -1) {
            return false;
        }

        beds[index] = null;

        inpatient.setBedNumber("NONE");
        inpatient.setWardNumber("NONE");

        return true;
    }

    public boolean releaseBedByBedNumber(String bedNumber) {

        int index = getBedIndex(bedNumber);

        if (index == -1 || beds[index] == null) {
            return false;
        }

        Patient patient = beds[index];

        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;

            inpatient.setBedNumber("NONE");
            inpatient.setWardNumber("NONE");
        }

        beds[index] = null;

        return true;
    }

    public boolean isBedOccupied(String bedNumber) {

        int index = getBedIndex(bedNumber);

        if (index == -1) {
            return false;
        }

        return beds[index] != null;
    }

    public boolean areAllBedsOccupied() {

        return getOccupiedBedCount() == TOTAL_BEDS;
    }

    public int getOccupiedBedCount() {

        int count = 0;

        for (Patient patient : beds) {
            if (patient != null) {
                count++;
            }
        }

        return count;
    }

    public int getAvailableBedCount() {

        return TOTAL_BEDS - getOccupiedBedCount();
    }

    public void displayWardLayout() {

        System.out.println(" ========== WARD " + WARD_NUMBER + " ==========");

        for (int i = 0; i < TOTAL_BEDS; i++) {

            String bedNumber = String.format("B%02d", i + 1);

            if (beds[i] == null) {
                System.out.printf("[%s: Available] ", bedNumber);
            } else {
                System.out.printf(
                        "[%s: %s] ",
                        bedNumber,
                        beds[i].getPatientId()
                );
            }

            if ((i + 1) % 5 == 0) {
                System.out.println();
            }
        }
    }

    public void displayAvailableBeds() {

        System.out.println(" ========== AVAILABLE BEDS ==========");

        boolean found = false;

        for (int i = 0; i < TOTAL_BEDS; i++) {

            if (beds[i] == null) {

                System.out.print(
                        String.format("B%02d ", i + 1)
                );

                found = true;
            }
        }

        if (!found) {
            System.out.println("No beds available.");
        } else {
            System.out.println();
        }
    }

    public void displayOccupiedBeds() {

        System.out.println(" ========== OCCUPIED BEDS ==========");

        boolean found = false;

        for (int i = 0; i < TOTAL_BEDS; i++) {

            if (beds[i] != null) {

                System.out.println(
                        String.format(
                                "B%02d -> Patient ID: %s, Name: %s %s",
                                i + 1,
                                beds[i].getPatientId(),
                                beds[i].getFirstName(),
                                beds[i].getLastName()
                        )
                );

                found = true;
            }
        }

        if (!found) {
            System.out.println("No occupied beds.");
        }
    }

    // ----------------------------------------------------
    // REPORTS
    // ----------------------------------------------------

    public void displayReport() {

        int registeredPatients = patients.size();
        int occupiedBeds = getOccupiedBedCount();
        int availableBeds = getAvailableBedCount();

        double occupancyPercentage =
                ((double) occupiedBeds / TOTAL_BEDS) * 100;

        System.out.println(" ========================================");
        System.out.println("          MEDICARE WARD REPORT");
        System.out.println("========================================");

        System.out.println("Total registered patients : "
                + registeredPatients);

        System.out.println("Total occupied beds       : "
                + occupiedBeds);

        System.out.println("Total available beds      : "
                + availableBeds);

        System.out.printf(
                "Ward occupancy percentage: %.2f%%%n",
                occupancyPercentage
        );

        System.out.println("========================================");
    }

    public int getTotalPatients() {
        return patients.size();
    }

    public double getOccupancyPercentage() {

        return ((double) getOccupiedBedCount() / TOTAL_BEDS) * 100;
    }
}
