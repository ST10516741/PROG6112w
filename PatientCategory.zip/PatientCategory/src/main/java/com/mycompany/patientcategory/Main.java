
package com.mycompany.patientcategory;

/**
 *
 * @author naledi
 */
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final HospitalSystem hospital = new HospitalSystem();

    public static void main(String[] args) {

        boolean running = true;

        System.out.println("==========================================");
        System.out.println("   MEDICARE HOSPITAL PATIENT SYSTEM");
        System.out.println("==========================================");

        while (running) {

            displayMainMenu();

            int choice = readInt("Enter your choice: ");

            switch (choice) {

                case 1:
                    registerPatient();
                    break;

                case 2:
                    searchPatient();
                    break;

                case 3:
                    updatePatient();
                    break;

                case 4:
                    deletePatient();
                    break;

                case 5:
                    hospital.displayAllPatients();
                    break;

                case 6:
                    allocateBed();
                    break;

                case 7:
                    releaseBed();
                    break;

                case 8:
                    hospital.displayWardLayout();
                    break;

                case 9:
                    hospital.displayAvailableBeds();
                    break;

                case 10:
                    hospital.displayOccupiedBeds();
                    break;

                case 11:
                    hospital.displayReport();
                    break;

                case 12:
                    hospital.displaySortedBySurname();
                    break;

                case 13:
                    hospital.displaySortedByPatientId();
                    break;

                case 0:
                    running = false;
                    System.out.println(" Thank you for using MediCare Hospital System.");
                    break;

                default:
                    System.out.println(" Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    // ----------------------------------------------------
    // MAIN MENU
    // ----------------------------------------------------

    private static void displayMainMenu() {

        System.out.println(" ==========================================");
        System.out.println("                MAIN MENU");
        System.out.println("==========================================");
        System.out.println("1.  Register Patient");
        System.out.println("2.  Search Patient");
        System.out.println("3.  Update Patient");
        System.out.println("4.  Delete Patient");
        System.out.println("5.  Display All Patients");
        System.out.println("------------------------------------------");
        System.out.println("6.  Allocate Bed");
        System.out.println("7.  Release Bed");
        System.out.println("8.  Display Ward Layout");
        System.out.println("9.  Display Available Beds");
        System.out.println("10. Display Occupied Beds");
        System.out.println("------------------------------------------");
        System.out.println("11. Display Ward Report");
        System.out.println("12. Sort Patients by Surname");
        System.out.println("13. Sort Patients by Patient ID");
        System.out.println("------------------------------------------");
        System.out.println("0.  Exit");
        System.out.println("==========================================");
    }

    // ----------------------------------------------------
    // REGISTER PATIENT
    // ----------------------------------------------------

    private static void registerPatient() {

        System.out.println(" ========== REGISTER PATIENT ==========");

        String patientId = readString("Patient ID: ");

        if (hospital.searchPatient(patientId) != null) {
            System.out.println("Error: Patient ID already exists.");
            return;
        }

        String firstName = readString("First Name: ");
        String lastName = readString("Last Name: ");
        int age = readInt("Age: ");
        String gender = readString("Gender: ");
        String condition = readString("Medical Condition:");

        PatientCategory category = readCategory();

        Patient patient;

        if (category == PatientCategory.INPATIENT) {

            patient = new Inpatient(
                    patientId,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    "NONE",
                    "NONE"
            );

        } else {

            patient = new Patient(
                    patientId,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    category
            );
        }

        if (hospital.registerPatient(patient)) {

            System.out.println("Patient registered successfully.");

        } else {

            System.out.println("Failed to register patient.");
        }
    }

    // ----------------------------------------------------
    // SEARCH PATIENT
    // ----------------------------------------------------

    private static void searchPatient() {

        System.out.println(" ========== SEARCH PATIENT ==========");

        String patientId = readString("Enter Patient ID: ");

        Patient patient = hospital.searchPatient(patientId);

        if (patient == null) {
            System.out.println("Patient not found.");
        } else {
            patient.displayDetails();
        }
    }

    // ----------------------------------------------------
    // UPDATE PATIENT
    // ----------------------------------------------------

    private static void updatePatient() {

        System.out.println(" ========== UPDATE PATIENT ==========");

        String patientId = readString("Enter Patient ID: ");

        Patient existingPatient = hospital.searchPatient(patientId);

        if (existingPatient == null) {
            System.out.println("Patient not found.");
            return;
        }

        System.out.println(" Enter the new information.");

        String firstName = readString("First Name: ");
        String lastName = readString("Last Name: ");
        int age = readInt("Age: ");
        String gender = readString("Gender: ");
        String condition = readString("Medical Condition:");

        PatientCategory category = readCategory();

        boolean success = hospital.updatePatient(
                patientId,
                firstName,
                lastName,
                age,
                gender,
                condition,
                category
        );

        if (success) {
            System.out.println("Patient updated successfully.");
        } else {
            System.out.println("Failed to update patient.");
        }
    }

    // ----------------------------------------------------
    // DELETE PATIENT
    // ----------------------------------------------------

    private static void deletePatient() {

        System.out.println(" ========== DELETE PATIENT ==========");

        String patientId = readString("Enter Patient ID: ");

        Patient patient = hospital.searchPatient(patientId);

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        patient.displayDetails();

        String confirmation =
                readString("Are you sure you want to delete this patient? (Y/N): ");

        if (confirmation.equalsIgnoreCase("Y")) {

            if (hospital.deletePatient(patientId)) {
                System.out.println("Patient deleted successfully.");
            } else {
                System.out.println("Failed to delete patient.");
            }

        } else {

            System.out.println("Delete operation cancelled.");
        }
    }

    // ----------------------------------------------------
    // ALLOCATE BED
    // ----------------------------------------------------

    private static void allocateBed() {

        System.out.println(" ========== ALLOCATE BED ==========");

        String patientId = readString("Enter Inpatient ID: ");

        Patient patient = hospital.searchPatient(patientId);

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        if (!(patient instanceof Inpatient)) {
            System.out.println(
                    "Error: Only Inpatients can be allocated a hospital bed."
            );
            return;
        }

        if (hospital.areAllBedsOccupied()) {
            System.out.println(
                    "Error: All 20 beds are currently occupied."
            );
            return;
        }

        hospital.displayAvailableBeds();

        String bedNumber =
                readString("Enter bed number to allocate (e.g. B01): ");

        if (hospital.allocateBed(patientId, bedNumber)) {

            System.out.println(
                    "Bed " + bedNumber.toUpperCase()
                            + " allocated successfully."
            );

        } else {

            System.out.println(
                    "Failed to allocate bed. "
                            + "The bed may already be occupied or invalid."
            );
        }
    }

    // ----------------------------------------------------
    // RELEASE BED
    // ----------------------------------------------------

    private static void releaseBed() {

        System.out.println(" ========== RELEASE BED ==========");

        String patientId = readString("Enter Patient ID: ");

        Patient patient = hospital.searchPatient(patientId);

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        if (!(patient instanceof Inpatient)) {
            System.out.println(
                    "This patient is not an inpatient."
            );
            return;
        }

        Inpatient inpatient = (Inpatient) patient;

        if (inpatient.getBedNumber().equalsIgnoreCase("NONE")) {
            System.out.println("This patient does not have a bed.");
            return;
        }

        System.out.println(
                "Current bed: " + inpatient.getBedNumber()
        );

        if (hospital.releaseBed(patientId)) {
            System.out.println("Bed released successfully.");
        } else {
            System.out.println("Failed to release bed.");
        }
    }

    // ----------------------------------------------------
    // CATEGORY INPUT
    // ----------------------------------------------------

    private static PatientCategory readCategory() {

        while (true) {

            System.out.println(" Patient Category:");
            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Emergency");

            int choice = readInt("Select category: ");

            switch (choice) {

                case 1:
                    return PatientCategory.INPATIENT;

                case 2:
                    return PatientCategory.OUTPATIENT;

                case 3:
                    return PatientCategory.EMERGENCY;

                default:
                    System.out.println(
                            "Invalid category. Please try again."
                    );
            }
        }
    }

    // ----------------------------------------------------
    // INPUT HELPERS
    // ----------------------------------------------------

    private static String readString(String message) {

        System.out.print(message);
        return scanner.nextLine().trim();
    }

    private static int readInt(String message) {

        while (true) {

            try {

                System.out.print(message);

                int value = Integer.parseInt(
                        scanner.nextLine().trim()
                );

                if (value < 0) {
                    System.out.println(
                            "Please enter a positive number."
                    );
                    continue;
                }

                return value;

            } catch (NumberFormatException e) {

                System.out.println(
                        "Invalid input. Please enter a number."
                );
            }
        }
    }
}

