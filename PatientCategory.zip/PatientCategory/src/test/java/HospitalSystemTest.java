package com.mycompany.patientcategory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class HospitalSystemTest {

    private HospitalSystem hospital;

    @BeforeEach
    void setUp() {
        hospital = new HospitalSystem();
    }

    // ----------------------------------------------------
    // 1. REGISTER A PATIENT
    // ----------------------------------------------------

    @Test
    void testRegisterPatient() {

        Patient patient = new Patient(
                "P001",
                "John",
                "Smith",
                35,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        boolean result = hospital.registerPatient(patient);

        assertTrue(result);
        assertEquals(1, hospital.getTotalPatients());
    }

    // ----------------------------------------------------
    // 2. SEARCH FOR A PATIENT
    // ----------------------------------------------------

    @Test
    void testSearchPatient() {

        Patient patient = new Patient(
                "P002",
                "Mary",
                "Jones",
                40,
                "Female",
                "Diabetes",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        Patient found = hospital.searchPatient("P002");

        assertNotNull(found);
        assertEquals("Mary", found.getFirstName());
        assertEquals("Jones", found.getLastName());
    }

    // ----------------------------------------------------
    // 3. UPDATE PATIENT DETAILS
    // ----------------------------------------------------

    @Test
    void testUpdatePatient() {

        Patient patient = new Patient(
                "P003",
                "Peter",
                "Brown",
                25,
                "Male",
                "Headache",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        boolean result = hospital.updatePatient(
                "P003",
                "Peter",
                "Wilson",
                26,
                "Male",
                "Migraine",
                PatientCategory.OUTPATIENT
        );

        assertTrue(result);

        Patient updated = hospital.searchPatient("P003");

        assertEquals("Wilson", updated.getLastName());
        assertEquals(26, updated.getAge());
        assertEquals("Migraine", updated.getMedicalCondition());
    }

    // ----------------------------------------------------
    // 4. DELETE PATIENT
    // ----------------------------------------------------

    @Test
    void testDeletePatient() {

        Patient patient = new Patient(
                "P004",
                "Alice",
                "Taylor",
                30,
                "Female",
                "Fever",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        assertTrue(hospital.deletePatient("P004"));

        assertNull(hospital.searchPatient("P004"));
        assertEquals(0, hospital.getTotalPatients());
    }

    // ----------------------------------------------------
    // 5. ALLOCATE A BED
    // ----------------------------------------------------

    @Test
    void testAllocateBed() {

        Inpatient patient = new Inpatient(
                "P005",
                "David",
                "Williams",
                50,
                "Male",
                "Pneumonia",
                "NONE",
                "NONE"
        );

        hospital.registerPatient(patient);

        boolean result =
                hospital.allocateBed("P005", "B01");

        assertTrue(result);
        assertTrue(hospital.isBedOccupied("B01"));

        assertEquals("B01", patient.getBedNumber());
        assertEquals("W01", patient.getWardNumber());
    }

    // ----------------------------------------------------
    // 6. RELEASE A BED
    // ----------------------------------------------------

    @Test
    void testReleaseBed() {

        Inpatient patient = new Inpatient(
                "P006",
                "Sarah",
                "Miller",
                45,
                "Female",
                "Asthma",
                "NONE",
                "NONE"
        );

        hospital.registerPatient(patient);

        hospital.allocateBed("P006", "B02");

        assertTrue(hospital.isBedOccupied("B02"));

        boolean result = hospital.releaseBed("P006");

        assertTrue(result);
        assertFalse(hospital.isBedOccupied("B02"));
        assertEquals("NONE", patient.getBedNumber());
    }

    // ----------------------------------------------------
    // 7. PREVENT DUPLICATE PATIENT IDS
    // ----------------------------------------------------

    @Test
    void testPreventDuplicatePatientIds() {

        Patient patient1 = new Patient(
                "P007",
                "Tom",
                "Green",
                20,
                "Male",
                "Cold",
                PatientCategory.OUTPATIENT
        );

        Patient patient2 = new Patient(
                "P007",
                "James",
                "Black",
                30,
                "Male",
                "Flu",
                PatientCategory.EMERGENCY
        );

        assertTrue(hospital.registerPatient(patient1));

        assertFalse(hospital.registerPatient(patient2));

        assertEquals(1, hospital.getTotalPatients());
    }

    // ----------------------------------------------------
    // 8. PREVENT ALLOCATING AN OCCUPIED BED
    // ----------------------------------------------------

    @Test
    void testPreventAllocatingOccupiedBed() {

        Inpatient patient1 = new Inpatient(
                "P008",
                "John",
                "Adams",
                30,
                "Male",
                "Flu",
                "NONE",
                "NONE"
        );

        Inpatient patient2 = new Inpatient(
                "P009",
                "Jane",
                "Adams",
                35,
                "Female",
                "Fever",
                "NONE",
                "NONE"
        );

        hospital.registerPatient(patient1);
        hospital.registerPatient(patient2);

        assertTrue(
                hospital.allocateBed("P008", "B03")
        );

        assertFalse(
                hospital.allocateBed("P009", "B03")
        );

        assertEquals(
                1,
                hospital.getOccupiedBedCount()
        );
    }

    // ----------------------------------------------------
    // 9. PREVENT ALLOCATION WHEN ALL BEDS ARE OCCUPIED
    // ----------------------------------------------------

    @Test
    void testPreventBedAllocationWhenAllBedsOccupied() {

        // Register 20 inpatients.
        for (int i = 1; i <= 20; i++) {

            String patientId =
                    String.format("P%03d", i);

            Inpatient patient = new Inpatient(
                    patientId,
                    "First" + i,
                    "Last" + i,
                    30,
                    "Male",
                    "Condition",
                    "NONE",
                    "NONE"
            );

            hospital.registerPatient(patient);

            String bedNumber =
                    String.format("B%02d", i);

            assertTrue(
                    hospital.allocateBed(
                            patientId,
                            bedNumber
                    )
            );
        }

        assertEquals(
                20,
                hospital.getOccupiedBedCount()
        );

        assertTrue(
                hospital.areAllBedsOccupied()
        );

        // Create an additional inpatient.
        Inpatient extraPatient = new Inpatient(
                "P021",
                "Extra",
                "Patient",
                40,
                "Female",
                "Condition",
                "NONE",
                "NONE"
        );

        hospital.registerPatient(extraPatient);

        // There should be no available bed.
        assertFalse(
                hospital.allocateFirstAvailableBed("P021")
        );

        assertEquals(
                20,
                hospital.getOccupiedBedCount()
        );
    }

    // ----------------------------------------------------
    // 10. SORT PATIENTS BY SURNAME AND PATIENT ID
    // ----------------------------------------------------

    @Test
    void testSortPatients() {

        Patient patient1 = new Patient(
                "P003",
                "John",
                "Zulu",
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        Patient patient2 = new Patient(
                "P001",
                "Mary",
                "Adams",
                25,
                "Female",
                "Cold",
                PatientCategory.OUTPATIENT
        );

        Patient patient3 = new Patient(
                "P002",
                "Peter",
                "Brown",
                40,
                "Male",
                "Fever",
                PatientCategory.EMERGENCY
        );

        hospital.registerPatient(patient1);
        hospital.registerPatient(patient2);
        hospital.registerPatient(patient3);

        // Test surname sorting.
        List<Patient> surnameSorted =
                hospital.sortBySurname();

        assertEquals(
                "Adams",
                surnameSorted.get(0).getLastName()
        );

        assertEquals(
                "Brown",
                surnameSorted.get(1).getLastName()
        );

        assertEquals(
                "Zulu",
                surnameSorted.get(2).getLastName()
        );

        // Test Patient ID sorting.
        List<Patient> idSorted =
                hospital.sortByPatientId();

        assertEquals(
                "P001",
                idSorted.get(0).getPatientId()
        );

        assertEquals(
                "P002",
                idSorted.get(1).getPatientId()
        );

        assertEquals(
                "P003",
                idSorted.get(2).getPatientId()
        );
    }
}
