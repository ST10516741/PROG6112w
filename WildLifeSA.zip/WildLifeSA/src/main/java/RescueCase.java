/** Abstract base class holding the data common to all rescue types. */
public abstract class RescueCase implements Rescuable {

    private final String caseId;
    private final String animalName;
    private final String species;
    private final String location;
    private final String ranger;
    private final int rescueDays;
    private final double dailyCareCost;
    private RescueStatus status;

    protected RescueCase(String caseId, String animalName, String species, String location,
                         String ranger, int rescueDays, double dailyCareCost) {
        requireText(caseId, "Rescue Case ID");
        requireText(species, "Species");
        requireText(location, "Rescue Location");
        requireText(ranger, "Assigned Ranger");
        requirePositive(rescueDays, "Number of Rescue Days");
        requirePositive(dailyCareCost, "Daily Care Cost");
        this.caseId = caseId.trim();
        this.animalName = (animalName == null || animalName.isBlank()) ? "Unnamed" : animalName.trim();
        this.species = species.trim();
        this.location = location.trim();
        this.ranger = ranger.trim();
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REPORTED;
    }

    // ---- validation helpers (shared with subclasses) ----
    protected static void requireText(String value, String field) {
        if (value == null || value.isBlank())
            throw new IllegalArgumentException(field + " must not be blank.");
    }

    protected static void requirePositive(double value, String field) {
        if (value <= 0)
            throw new IllegalArgumentException(field + " must be greater than zero.");
    }

    // ---- abstract behaviour: each rescue type supplies its own ----
    public abstract String getRescueType();
    protected abstract double calculateAdditionalCost();
    public abstract RescuePriority determinePriority();
    public abstract String getSpecificDetails();

    /** Template: base care cost plus the type-specific costs. */
    public double calculateTotalCost() {
        return rescueDays * dailyCareCost + calculateAdditionalCost();
    }

    // ---- Rescuable ----
    @Override
    public void startRescue() {
        if (status != RescueStatus.REPORTED)
            throw new IllegalStateException("Only a reported rescue can be started (current status: " + status + ").");
        status = RescueStatus.IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        if (status != RescueStatus.IN_PROGRESS)
            throw new IllegalStateException("Only an in-progress rescue can be completed (current status: " + status + ").");
        status = RescueStatus.COMPLETED;
    }

    @Override
    public String generateSummary() {
        return String.format(
            "--- Rescue Summary ---%n" +
            "Rescue Case ID : %s%n" +
            "Rescue Type    : %s%n" +
            "Species        : %s%n" +
            "Assigned Ranger: %s%n" +
            "Priority       : %s%n" +
            "Status         : %s%n" +
            "Total Cost     : %s",
            caseId, getRescueType(), species, ranger, determinePriority(), status,
            formatMoney(calculateTotalCost()));
    }

    public static String formatMoney(double amount) {
        return String.format(java.util.Locale.US, "R%,.2f", amount);
    }

    // ---- getters / controlled setter ----
    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getLocation() { return location; }
    public String getRanger() { return ranger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public RescueStatus getStatus() { return status; }

    public void setStatus(RescueStatus newStatus) {
        if (newStatus == null) throw new IllegalArgumentException("Status must not be null.");
        this.status = newStatus;
    }

    @Override
    public String toString() {
        return String.format("ID: %s | %s | Animal: %s | Species: %s | Location: %s | Ranger: %s%n" +
                "      Days: %d | Daily Cost: %s | Status: %s | Priority: %s | Total: %s%n      %s",
                caseId, getRescueType(), animalName, species, location, ranger,
                rescueDays, formatMoney(dailyCareCost), status, determinePriority(),
                formatMoney(calculateTotalCost()), getSpecificDetails());
    }
}
