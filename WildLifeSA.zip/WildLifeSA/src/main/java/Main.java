import java.util.Scanner;

/*
 * WildLife SA Rescue Operations System (standard Java only).
 * Name: ______________   Student No: ______________
 */
public class Main {
    private static final Scanner in = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printMenu();
            switch (readInt("Enter choice: ", 1, 9)) {
                case 1 -> createCase();
                case 2 -> searchCase();
                case 3 -> updateStatus();
                case 4 -> displayAll();
                case 5 -> operate("start");
                case 6 -> operate("complete");
                case 7 -> operate("summary");
                case 8 -> System.out.println(manager.generateReport());
                case 9 -> { running = false; System.out.println("Goodbye."); }
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n===== WildLife SA Rescue Operations =====");
        System.out.println("1. Create new rescue case");
        System.out.println("2. Search rescue case by ID");
        System.out.println("3. Update rescue status");
        System.out.println("4. Display all rescue cases");
        System.out.println("5. Start rescue operation");
        System.out.println("6. Complete rescue operation");
        System.out.println("7. Generate rescue summary");
        System.out.println("8. Generate rescue report");
        System.out.println("9. Exit");
    }

    private static void createCase() {
        System.out.println("\nRescue type: 1. Injured  2. Orphaned  3. Endangered Species");
        int type = readInt("Select type: ", 1, 3);

        String id;
        while (true) {
            id = readText("Rescue Case ID: ");
            if (manager.idExists(id)) System.out.println("Error: that Rescue Case ID already exists.");
            else break;
        }
        System.out.print("Animal Name (optional): ");
        String name = in.nextLine();
        String species = readText("Species: ");
        String location = readText("Rescue Location: ");
        String ranger = readText("Assigned Ranger: ");
        int days = readInt("Number of Rescue Days: ", 1, Integer.MAX_VALUE);
        double daily = readPositiveDouble("Daily Care Cost (R): ");

        RescueCase rc;
        switch (type) {
            case 1 -> rc = new InjuredAnimalRescue(id, name, species, location, ranger, days, daily,
                    readText("Injury Description: "),
                    readPositiveDouble("Veterinary Treatment Cost (R): "),
                    readYesNo("Surgery required?"));
            case 2 -> rc = new OrphanedAnimalRescue(id, name, species, location, ranger, days, daily,
                    readInt("Estimated Age (months): ", 1, Integer.MAX_VALUE),
                    readPositiveDouble("Feeding Cost (R): "),
                    readYesNo("Foster care required?"));
            default -> rc = new EndangeredSpeciesRescue(id, name, species, location, ranger, days, daily,
                    readText("Conservation Classification: "),
                    readPositiveDouble("Security Cost (R): "),
                    readYesNo("Specialist team required?"));
        }
        manager.addCase(rc);
        System.out.println("Rescue case created successfully.");
    }

    private static void searchCase() {
        RescueCase c = manager.findById(readText("Rescue Case ID to search: "));
        System.out.println(c == null ? "No rescue case found with that ID." : c);
    }

    private static void updateStatus() {
        RescueCase c = manager.findById(readText("Rescue Case ID: "));
        if (c == null) { System.out.println("No rescue case found with that ID."); return; }
        System.out.println("Current status: " + c.getStatus());
        System.out.println("1. Reported  2. In Progress  3. Completed");
        int choice = readInt("New status: ", 1, 3);
        c.setStatus(RescueStatus.values()[choice - 1]);
        System.out.println("Status updated to: " + c.getStatus());
    }

    private static void displayAll() {
        if (manager.getCaseCount() == 0) { System.out.println("No rescue cases recorded."); return; }
        for (RescueCase c : manager.getAllCases()) System.out.println(c + System.lineSeparator());
    }

    private static void operate(String action) {
        RescueCase c = manager.findById(readText("Rescue Case ID: "));
        if (c == null) { System.out.println("No rescue case found with that ID."); return; }
        try {
            switch (action) {
                case "start" -> { c.startRescue(); System.out.println("Rescue started. Status: " + c.getStatus()); }
                case "complete" -> { c.completeRescue(); System.out.println("Rescue completed. Status: " + c.getStatus()); }
                default -> System.out.println(c.generateSummary());
            }
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ---------- input helpers: keep prompting until the input is valid ----------
    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Error: this field cannot be blank.");
        }
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int v = Integer.parseInt(in.nextLine().trim());
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println(max == Integer.MAX_VALUE
                    ? "Error: enter a whole number of at least " + min + "."
                    : "Error: enter a number between " + min + " and " + max + ".");
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double v = Double.parseDouble(in.nextLine().trim());
                if (v > 0 && !Double.isInfinite(v)) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println("Error: enter a number greater than zero.");
        }
    }

    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String s = in.nextLine().trim();
            if (s.equalsIgnoreCase("Y")) return true;
            if (s.equalsIgnoreCase("N")) return false;
            System.out.println("Error: enter Y or N.");
        }
    }
}
