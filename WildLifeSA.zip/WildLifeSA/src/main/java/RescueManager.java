import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// ================= RescueManager =================

/** Manages the collection of rescue cases (stored in an ArrayList). */
public class RescueManager {
    private final ArrayList<RescueCase> cases = new ArrayList<>();

    /** @throws IllegalArgumentException if the case is null or its ID already exists */
    public void addCase(RescueCase rescueCase) {
        if (rescueCase == null) throw new IllegalArgumentException("Rescue case must not be null.");
        if (idExists(rescueCase.getCaseId()))
            throw new IllegalArgumentException("Rescue Case ID '" + rescueCase.getCaseId() + "' already exists.");
        cases.add(rescueCase);
    }

    public boolean idExists(String id) {
        return findById(id) != null;
    }

    /** @return the matching case (ID is case-insensitive) or null if not found */
    public RescueCase findById(String id) {
        if (id == null) return null;
        for (RescueCase c : cases) {
            if (c.getCaseId().equalsIgnoreCase(id.trim())) return c;
        }
        return null;
    }

    public boolean updateStatus(String id, RescueStatus newStatus) {
        RescueCase c = findById(id);
        if (c == null) return false;
        c.setStatus(newStatus);
        return true;
    }

    public List<RescueCase> getAllCases() {
        return Collections.unmodifiableList(cases);
    }

    public int getCaseCount() { return cases.size(); }

    public double getTotalEstimatedCost() {
        double total = 0;
        for (RescueCase c : cases) total += c.calculateTotalCost(); // polymorphic call
        return total;
    }

    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        String line = "=".repeat(128);
        sb.append(line).append(System.lineSeparator());
        sb.append("                                     WILDLIFE SA - RESCUE REPORT").append(System.lineSeparator());
        sb.append(line).append(System.lineSeparator());
        sb.append(String.format("%-8s %-20s %-16s %-18s %-16s %-10s %-12s %14s%n",
                "ID", "Type", "Species", "Location", "Ranger", "Priority", "Status", "Total Cost"));
        sb.append("-".repeat(128)).append(System.lineSeparator());
        if (cases.isEmpty()) sb.append("No rescue cases recorded.").append(System.lineSeparator());
        for (RescueCase c : cases) {
            sb.append(String.format("%-8s %-20s %-16s %-18s %-16s %-10s %-12s %14s%n",
                    c.getCaseId(), c.getRescueType(), c.getSpecies(), c.getLocation(), c.getRanger(),
                    c.determinePriority(), c.getStatus(), RescueCase.formatMoney(c.calculateTotalCost())));
        }
        sb.append("-".repeat(128)).append(System.lineSeparator());
        sb.append(String.format("Total Rescue Cases        : %d%n", getCaseCount()));
        sb.append(String.format("Total Estimated Rescue Cost: %s%n", RescueCase.formatMoney(getTotalEstimatedCost())));
        sb.append(line);
        return sb.toString();
    }
}
