public enum RescuePriority {
    LOW, MEDIUM, HIGH, CRITICAL
}
